@extends('layouts.app')

@section('title', 'عنا')

@section('content')
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card shadow-lg border-0">
                <div class="card-header bg-primary text-white text-center py-4">
                    <h2 class="mb-0"><i class="bi bi-info-circle-fill me-2"></i>عن المسابقة</h2>
                </div>
                <div class="card-body p-5">
                    <div class="text-center mb-5">
                        <i class="bi bi-moon-stars-fill text-warning display-1"></i>
                        <h3 class="mt-3">مسابقة رمضان الثقافية</h3>
                        <p class="lead text-muted">تنظيم كلية العلوم والآداب - جامعة تعز</p>
                    </div>

                    <div class="row mt-5">
                        <div class="col-md-6 mb-4">
                            <div class="d-flex">
                                <div class="me-3">
                                    <span class="badge bg-primary rounded-circle p-3"><i class="bi bi-building fs-4"></i></span>
                                </div>
                                <div>
                                    <h5>عن الكلية</h5>
                                    <p class="text-muted">كلية العلوم والآداب هي إحدى كليات جامعة تعز، تأسست عام 1995م، وتسعى إلى تخريج كوادر مؤهلة في مختلف التخصصات العلمية والإنسانية.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="d-flex">
                                <div class="me-3">
                                    <span class="badge bg-success rounded-circle p-3"><i class="bi bi-trophy fs-4"></i></span>
                                </div>
                                <div>
                                    <h5>عن المسابقة</h5>
                                    <p class="text-muted">مسابقة يومية طوال شهر رمضان المبارك، تهدف إلى تنمية المعرفة الثقافية والدينية وتعزيز الروح التنافسية بين الطلاب.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="d-flex">
                                <div class="me-3">
                                    <span class="badge bg-info rounded-circle p-3"><i class="bi bi-people fs-4"></i></span>
                                </div>
                                <div>
                                    <h5>الفريق المنظم</h5>
                                    <p class="text-muted">يشرف على المسابقة نخبة من أعضاء هيئة التدريس بالكلية، بدعم من عمادة الكلية وإدارة الجامعة.</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 mb-4">
                            <div class="d-flex">
                                <div class="me-3">
                                    <span class="badge bg-warning rounded-circle p-3"><i class="bi bi-code-slash fs-4"></i></span>
                                </div>
                                <div>
                                    <h5>المطورون</h5>
                                    <p class="text-muted">تم تطوير هذا الموقع بواسطة فريق طلابي من قسم تقنية المعلومات، بإشراف د. محمد عبدالله.</p>
                                    <ul class="list-unstyled">
                                        <li><i class="bi bi-person-circle me-2"></i> أحمد علي - قائد الفريق</li>
                                        <li><i class="bi bi-person-circle me-2"></i> فاطمة صالح - مطور واجهات</li>
                                        <li><i class="bi bi-person-circle me-2"></i> عبدالله محمود - مطور خلفية</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection