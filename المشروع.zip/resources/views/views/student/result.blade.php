@extends('layouts.app')

@section('title', 'نتيجة الاختبار')

@push('styles')
<style>
    .result-card {
        background: linear-gradient(145deg, #ffffff, #f8f9fa);
        border-radius: 40px;
        box-shadow: 0 20px 50px rgba(0,0,0,0.1);
    }
    [data-bs-theme="dark"] .result-card {
        background: linear-gradient(145deg, #2d2d44, #24243a);
    }
    .score-badge {
        font-size: 2.5rem;
        font-weight: 900;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
</style>
@endpush

@section('content')
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="result-card p-5 text-center">
                <i class="bi bi-trophy-fill text-warning display-1 mb-4"></i>
                <h2 class="mb-3">تهانينا! 🎉</h2>
                <p class="lead mb-4">لقد أكملت اختبار اليوم {{ $attempt->competition->day_number }}</p>

                <div class="row g-4 mb-5">
                    <div class="col-4">
                        <div class="border-0 bg-light p-3 rounded-4">
                            <div class="small text-muted">الصحيح</div>
                            <div class="fs-1 fw-bold text-success">{{ $attempt->correct_count }}</div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="border-0 bg-light p-3 rounded-4">
                            <div class="small text-muted">الخطأ</div>
                            <div class="fs-1 fw-bold text-danger">{{ $attempt->wrong_count }}</div>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="border-0 bg-light p-3 rounded-4">
                            <div class="small text-muted">بدون إجابة</div>
                            <div class="fs-1 fw-bold text-secondary">{{ $attempt->blank_count }}</div>
                        </div>
                    </div>
                </div>

                <div class="d-grid gap-3">
                    <a href="{{ route('home') }}" class="btn btn-primary btn-lg">
                        <i class="bi bi-house-door me-2"></i>العودة للرئيسية
                    </a>
                    <a href="{{ route('student.leaderboard', ['competition_id' => $attempt->competition_id]) }}"
                       class="btn btn-outline-warning btn-lg">
                        <i class="bi bi-bar-chart me-2"></i>عرض المتصدرين
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection