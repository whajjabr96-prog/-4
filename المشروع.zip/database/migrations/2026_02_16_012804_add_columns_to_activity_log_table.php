<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('activity_log', function (Blueprint $table) {
            $table->text('description')->nullable()->after('log_name');
            $table->nullableMorphs('causer'); // يضيف causer_type و causer_id
            $table->json('properties')->nullable()->after('causer_id');
        });
    }

    public function down(): void
    {
        Schema::table('activity_log', function (Blueprint $table) {
            $table->dropColumn(['description', 'causer_type', 'causer_id', 'properties']);
        });
    }
};