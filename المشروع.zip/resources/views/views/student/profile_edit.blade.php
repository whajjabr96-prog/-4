@extends('layouts.app')

@section('title', 'تعديل الملف الشخصي')

@section('content')
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-warning">
                    <h4 class="mb-0"><i class="bi bi-pencil-square me-2"></i>طلب تعديل البيانات</h4>
                </div>
                <div class="card-body">
                    <form method="POST" action="{{ route('student.profile.update') }}">
                        @csrf

                        <div class="mb-3">
                            <label class="form-label">الاسم</label>
                            <input type="text" name="name" class="form-control" value="{{ old('name', $user->name) }}" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">البريد الإلكتروني</label>
                            <input type="email" name="email" class="form-control" value="{{ old('email', $user->email) }}" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">رقم الهاتف</label>
                            <input type="text" name="phone" class="form-control" value="{{ old('phone', $user->phone) }}" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">التخصص (اختياري)</label>
                            <input type="text" name="major" class="form-control" value="{{ old('major', $user->major) }}">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">رقم القيد (اختياري)</label>
                            <input type="text" name="student_no" class="form-control" value="{{ old('student_no', $user->student_no) }}">
                        </div>

                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i>
                            بعد إرسال الطلب، سيقوم الأدمن بمراجعته والموافقة عليه. سيتم إشعارك عند الانتهاء.
                        </div>

                        <button type="submit" class="btn btn-primary">إرسال الطلب</button>
                        <a href="{{ route('student.profile') }}" class="btn btn-secondary">إلغاء</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection