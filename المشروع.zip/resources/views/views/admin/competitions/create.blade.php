@extends('layouts.app')

@section('title', 'إنشاء يوم جديد')

@section('content')
<div class="container py-4" style="max-width: 600px;">
    <div class="card shadow-sm border-0">
        <div class="card-header bg-white">
            <h4 class="mb-0 fw-bold"><i class="bi bi-plus-circle me-2"></i>إنشاء يوم جديد</h4>
        </div>
        <div class="card-body">
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form method="POST" action="{{ route('admin.competitions.store') }}">
                @csrf

                <div class="mb-3">
                    <label class="form-label fw-medium">رقم اليوم (1-30)</label>
                    <input type="number" name="day_number" class="form-control @error('day_number') is-invalid @enderror" value="{{ old('day_number') }}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-medium">عنوان اليوم (اختياري)</label>
                    <input type="text" name="title" class="form-control" value="{{ old('title') }}">
                </div>

                <div class="mb-3">
                    <label class="form-label fw-medium">وقت البداية</label>
                    <input type="datetime-local" name="starts_at" class="form-control" value="{{ old('starts_at') }}" required>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-medium">وقت النهاية</label>
                    <input type="datetime-local" name="ends_at" class="form-control" value="{{ old('ends_at') }}" required>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-primary">حفظ</button>
                    <a href="{{ route('admin.competitions') }}" class="btn btn-outline-secondary">إلغاء</a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection