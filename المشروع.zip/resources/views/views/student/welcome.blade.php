@extends('layouts.app')

@section('title', 'تم التسجيل بنجاح - المسابقة الرمضانية الكبرى')

@section('content')
<!-- Google Fonts - Tajawal & Amiri -->
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;900&family=Amiri:wght@400;700&display=swap" rel="stylesheet">
<!-- Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<!-- Animate.css -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>

<style>
    :root {
        --primary-gold: #f7b731;
        --secondary-gold: #ffd966;
        --dark-blue: #0b1a33;
        --mid-blue: #1a3a5f;
        --glass-bg: rgba(255, 255, 255, 0.08);
        --glass-border: rgba(255, 255, 255, 0.15);
    }

    .ramadan-body {
        font-family: 'Tajawal', sans-serif;
        background: radial-gradient(circle at center, var(--mid-blue) 0%, var(--dark-blue) 100%);
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        overflow: hidden;
        color: white;
        direction: rtl;
    }

    /* Islamic Pattern Overlay */
    .ramadan-body::before {
        content: "";
        position: absolute;
        top: 0; left: 0; right: 0; bottom: 0;
        background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"><path d="M50 0 L60 40 L100 50 L60 60 L50 100 L40 60 L0 50 L40 40 Z" fill="rgba(255,215,0,0.03)"/></svg>');
        background-size: 80px 80px;
        opacity: 0.4;
        z-index: 0;
        pointer-events: none;
    }

    /* Moon Crescent */
    .moon-crescent {
        position: absolute;
        top: 40px;
        right: 40px;
        width: 100px;
        height: 100px;
        border-radius: 50%;
        box-shadow: -20px 10px 0 0 var(--primary-gold);
        transform: rotate(-15deg);
        filter: drop-shadow(0 0 15px rgba(247, 212, 74, 0.6));
        animation: floatMoon 8s infinite ease-in-out;
        z-index: 1;
    }

    @keyframes floatMoon {
        0%, 100% { transform: translateY(0) rotate(-15deg); }
        50% { transform: translateY(-15px) rotate(-10deg); }
    }

    /* Glassmorphism Card */
    .main-card {
        background: var(--glass-bg);
        backdrop-filter: blur(25px);
        -webkit-backdrop-filter: blur(25px);
        border: 1px solid var(--glass-border);
        border-radius: 40px;
        padding: 4rem 2rem;
        max-width: 800px;
        width: 95%;
        text-align: center;
        box-shadow: 0 25px 50px rgba(0, 0, 0, 0.4);
        position: relative;
        z-index: 10;
        margin: 2rem auto;
    }

    /* Typography */
    h1 {
        font-family: 'Amiri', serif;
        font-weight: 700;
        font-size: 3.5rem;
        margin-bottom: 1rem;
        background: linear-gradient(to bottom, #fff 20%, var(--primary-gold) 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        filter: drop-shadow(0 2px 4px rgba(0,0,0,0.3));
    }

    .success-star {
        font-size: 5rem;
        color: var(--primary-gold);
        filter: drop-shadow(0 0 20px var(--primary-gold));
        animation: pulse 2s infinite;
        margin-bottom: 1.5rem;
    }

    @keyframes pulse {
        0%, 100% { transform: scale(1); opacity: 0.8; }
        50% { transform: scale(1.1); opacity: 1; }
    }

    .instruction-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 1.5rem;
        margin-top: 3rem;
        text-align: right;
    }

    .instruction-item {
        background: rgba(255, 255, 255, 0.05);
        padding: 1.5rem;
        border-radius: 20px;
        border: 1px solid rgba(255, 255, 255, 0.1);
        transition: all 0.3s ease;
    }

    .instruction-item:hover {
        background: rgba(255, 255, 255, 0.1);
        transform: translateY(-5px);
        border-color: var(--primary-gold);
    }

    .step-num {
        width: 40px;
        height: 40px;
        background: var(--primary-gold);
        color: var(--dark-blue);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 900;
        margin-bottom: 1rem;
    }

    .btn-gold {
        background: linear-gradient(135deg, var(--primary-gold), #d49a1e);
        color: var(--dark-blue) !important;
        padding: 1rem 3rem;
        border-radius: 50px;
        font-weight: 700;
        font-size: 1.3rem;
        text-decoration: none;
        display: inline-block;
        transition: all 0.4s ease;
        box-shadow: 0 10px 20px rgba(212, 154, 30, 0.3);
        border: none;
        margin-top: 2rem;
    }

    .btn-gold:hover {
        transform: translateY(-5px) scale(1.05);
        box-shadow: 0 15px 30px rgba(212, 154, 30, 0.5);
    }

    .status-badge {
        display: inline-block;
        padding: 0.5rem 1.5rem;
        background: rgba(231, 76, 60, 0.2);
        border: 1px solid #e74c3c;
        color: #ff7675;
        border-radius: 10px;
        font-weight: bold;
        margin-bottom: 2rem;
        animation: flash 2s infinite;
    }

    @keyframes flash {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.6; }
    }

    @media (max-width: 768px) {
        h1 { font-size: 2.5rem; }
        .main-card { padding: 2rem 1rem; }
    }
</style>

<div class="ramadan-body">
    <!-- Background Moon -->
    <div class="moon-crescent"></div>

    <div class="main-card animate__animated animate__zoomIn">
        <i class="bi bi-star-fill success-star animate__animated animate__bounceIn animate__delay-1s"></i>
        
        <h1 class="animate__animated animate__fadeInDown animate__delay-1s">تم التسجيل بنجاح!</h1>
        
        <p class="subtitle fs-4 mb-4 animate__animated animate__fadeIn animate__delay-2s">
            أهلاً بك يا بطل، <span class="highlight text-warning fw-bold">{{ auth()->user()->name }}</span> في مسابقة رمضان الكبرى
        </p>

        <div class="status-badge animate__animated animate__fadeIn animate__delay-2s">
            <i class="bi bi-hourglass-split me-2"></i>
            حسابك قيد المراجعة حالياً من قبل الإدارة
        </div>

        <div class="instruction-grid">
            <div class="instruction-item animate__animated animate__fadeInUp animate__delay-3s">
                <div class="step-num">١</div>
                <h5 class="text-warning fw-bold">موعد التحدي</h5>
                <p class="small opacity-75 mb-0">يفتح الميدان يومياً من 9:00 م حتى 11:00 م بتوقيت مكة المكرمة.</p>
            </div>
            <div class="instruction-item animate__animated animate__fadeInUp animate__delay-3s">
                <div class="step-num">٢</div>
                <h5 class="text-warning fw-bold">فرصة واحدة</h5>
                <p class="small opacity-75 mb-0">لديك محاولة واحدة فقط يومياً. تأكد من جاهزيتك التامة قبل البدء.</p>
            </div>
            <div class="instruction-item animate__animated animate__fadeInUp animate__delay-4s">
                <div class="step-num">٣</div>
                <h5 class="text-warning fw-bold">سباق الزمن</h5>
                <p class="small opacity-75 mb-0">لكل سؤال 30 ثانية فقط. السرعة والدقة هما مفتاحك للفوز بالمركز الأول.</p>
            </div>
            <div class="instruction-item animate__animated animate__fadeInUp animate__delay-4s">
                <div class="step-num">٤</div>
                <h5 class="text-warning fw-bold">لا تراجع</h5>
                <p class="small opacity-75 mb-0">بمجرد اختيار الإجابة، لا يمكنك العودة للخلف. ثق بذكائك وانطلق.</p>
            </div>
        </div>

        <div class="mt-5 animate__animated animate__fadeInUp animate__delay-5s">
            <a href="{{ route('home') }}" class="btn-gold">
                <i class="bi bi-house-door-fill me-2"></i>
                العودة إلى الصفحة الرئيسية
            </a>
        </div>
    </div>
</div>
@endsection
