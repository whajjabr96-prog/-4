

<?php $__env->startSection('title', 'سجل النشاطات'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <h2 class="fw-bold mb-4"><i class="bi bi-clock-history me-2"></i>سجل النشاطات</h2>

    <div class="card shadow-sm border-0">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>الوقت</th>
                            <th>المستخدم</th>
                            <th>الوصف</th>
                            <th>التفاصيل</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($log->created_at->format('Y-m-d H:i:s')); ?></td>
                                <td>
                                    <?php if($log->causer): ?>
                                        <span class="fw-medium"><?php echo e($log->causer->name); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">نظام</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($log->description); ?></td>
                                <td>
                                    <?php if($log->properties): ?>
                                        <button class="btn btn-sm btn-outline-info" type="button" data-bs-toggle="collapse" data-bs-target="#log-<?php echo e($log->id); ?>">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                        <div class="collapse mt-2" id="log-<?php echo e($log->id); ?>">
                                            <pre class="bg-light p-2 rounded small"><?php echo e(json_encode($log->properties, JSON_PRETTY_PRINT)); ?></pre>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center text-muted py-4">لا توجد نشاطات.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($logs->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ramadan1-quiz\resources\views/admin/activity_log/index.blade.php ENDPATH**/ ?>