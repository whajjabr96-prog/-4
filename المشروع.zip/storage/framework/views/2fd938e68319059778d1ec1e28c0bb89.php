

<?php $__env->startSection('title', 'تفاصيل اليوم ' . $competition->day_number); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold"><i class="bi bi-calendar2-day me-2"></i>اليوم <?php echo e($competition->day_number); ?>: <?php echo e($competition->title ?? ''); ?></h2>
        <div>
            <a href="<?php echo e(route('admin.competitions')); ?>" class="btn btn-outline-secondary me-2">
                <i class="bi bi-arrow-right"></i> العودة
            </a>
            <form method="POST" action="<?php echo e(route('admin.competitions.toggle', $competition)); ?>" class="d-inline">
                <?php echo csrf_field(); ?>
                <button class="btn btn-outline-<?php echo e($competition->is_published ? 'secondary' : 'success'); ?>">
                    <i class="bi bi-<?php echo e($competition->is_published ? 'eye-slash' : 'eye'); ?>"></i>
                    <?php echo e($competition->is_published ? 'إلغاء النشر' : 'نشر'); ?>

                </button>
            </form>
        </div>
    </div>

    <div class="row">
        <!-- معلومات اليوم -->
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-header bg-white">
                    <h5 class="mb-0"><i class="bi bi-info-circle me-2"></i>معلومات اليوم</h5>
                </div>
                <div class="card-body">
                    <p><strong>رقم اليوم:</strong> <?php echo e($competition->day_number); ?></p>
                    <p><strong>العنوان:</strong> <?php echo e($competition->title ?? '—'); ?></p>
                    <p><strong>البداية:</strong> <?php echo e($competition->starts_at->format('Y-m-d h:i A')); ?></p>
                    <p><strong>النهاية:</strong> <?php echo e($competition->ends_at->format('Y-m-d h:i A')); ?></p>
                    <p><strong>الحالة:</strong>
                        <?php if($competition->is_published): ?>
                            <span class="badge bg-success">منشور</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">غير منشور</span>
                        <?php endif; ?>
                    </p>
                    <p><strong>عدد المشاركين:</strong> <?php echo e($competition->attempts()->count()); ?></p>
                </div>
            </div>
        </div>

        <!-- الأسئلة المرتبطة -->
        <div class="col-md-8 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="bi bi-patch-question me-2"></i>أسئلة اليوم</h5>
                    <a href="<?php echo e(route('admin.questions.create', ['competition_id' => $competition->id])); ?>" class="btn btn-sm btn-primary">
                        <i class="bi bi-plus-circle me-1"></i>إضافة سؤال
                    </a>
                </div>
                <div class="card-body">
                    <?php if($competition->questions->isEmpty()): ?>
                        <p class="text-muted text-center py-3">لا توجد أسئلة مرتبطة بهذا اليوم.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>السؤال</th>
                                        <th>الخيارات</th>
                                        <th>الإجابة</th>
                                        <th>الإجراءات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $competition->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($question->pivot->sort_order); ?></td>
                                            <td><?php echo e(Str::limit($question->text, 50)); ?></td>
                                            <td>
                                                <small>A: <?php echo e(Str::limit($question->choice_a, 15)); ?><br>
                                                B: <?php echo e(Str::limit($question->choice_b, 15)); ?><br>
                                                C: <?php echo e(Str::limit($question->choice_c, 15)); ?><br>
                                                D: <?php echo e(Str::limit($question->choice_d, 15)); ?></small>
                                            </td>
                                            <td><?php echo e($question->correct_choice); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('admin.questions.edit', $question)); ?>" class="btn btn-sm btn-outline-warning">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- الفائزون -->
        <div class="col-12">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="bi bi-trophy me-2"></i>الفائزون</h5>
                    <a href="<?php echo e(route('admin.competitions.winners.index', $competition)); ?>" class="btn btn-sm btn-warning">
                        <i class="bi bi-gear me-1"></i>إدارة الفائزين
                    </a>
                </div>
                <div class="card-body">
                    <?php if($competition->winners->isEmpty()): ?>
                        <p class="text-muted text-center py-3">لم يتم تحديد فائزين بعد.</p>
                    <?php else: ?>
                        <div class="row">
                            <?php $__currentLoopData = $competition->winners->sortBy('rank'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $winner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4 mb-3">
                                    <div class="border rounded p-3 text-center">
                                        <?php if($winner->rank == 1): ?> 🥇
                                        <?php elseif($winner->rank == 2): ?> 🥈
                                        <?php elseif($winner->rank == 3): ?> 🥉
                                        <?php endif; ?>
                                        <h5 class="mt-2"><?php echo e($winner->user->name); ?></h5>
                                        <span class="badge bg-primary">المركز <?php echo e($winner->rank); ?></span>
                                        <?php if($winner->note): ?>
                                            <p class="small text-muted mt-2"><?php echo e($winner->note); ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ramadan1-quiz\resources\views\admin\competitions\show.blade.php ENDPATH**/ ?>