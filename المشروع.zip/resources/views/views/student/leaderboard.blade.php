@extends('layouts.app')

@section('title', 'الفائزون')

@push('styles')
<style>
    .winner-card {
        background: linear-gradient(145deg, #ffffff, #f8f9fa);
        border-radius: 30px;
        padding: 2rem;
        box-shadow: 0 15px 40px rgba(0,0,0,0.1);
        transition: all 0.3s;
    }
    .winner-card:hover {
        transform: translateY(-10px);
    }
    .trophy-gold { color: #ffd700; }
    .trophy-silver { color: #c0c0c0; }
    .trophy-bronze { color: #cd7f32; }
    [data-bs-theme="dark"] .winner-card {
        background: linear-gradient(145deg, #2d2d44, #24243a);
    }
</style>
@endpush

@section('content')
<div class="container py-5">
    <h2 class="text-center mb-5 fw-bold">
        <i class="bi bi-trophy-fill text-warning me-2"></i>
        فائزو اليوم {{ $competition->day_number ?? '' }}
    </h2>

    @if($winners->isNotEmpty())
        <div class="row justify-content-center">
            @foreach($winners as $winner)
                <div class="col-md-4 mb-4">
                    <div class="winner-card text-center">
                        @if($winner->rank == 1)
                            <i class="bi bi-trophy-fill display-1 trophy-gold"></i>
                            <h3 class="mt-3 fw-bold">🥇 المركز الأول</h3>
                        @elseif($winner->rank == 2)
                            <i class="bi bi-trophy-fill display-1 trophy-silver"></i>
                            <h3 class="mt-3 fw-bold">🥈 المركز الثاني</h3>
                        @elseif($winner->rank == 3)
                            <i class="bi bi-trophy-fill display-1 trophy-bronze"></i>
                            <h3 class="mt-3 fw-bold">🥉 المركز الثالث</h3>
                        @else
                            <i class="bi bi-award-fill display-1 text-info"></i>
                            <h3 class="mt-3 fw-bold">المركز {{ $winner->rank }}</h3>
                        @endif
                        <h4 class="fw-bold mt-3">{{ $winner->user->name }}</h4>
                        @if($winner->note)
                            <p class="text-muted mt-2">{{ $winner->note }}</p>
                        @endif
                    </div>
                </div>
            @endforeach
        </div>

        <div class="text-center mt-5">
            <a href="{{ route('home') }}" class="btn btn-primary btn-lg px-5">
                <i class="bi bi-house-door me-2"></i>العودة للرئيسية
            </a>
        </div>
    @else
        <div class="alert alert-info text-center py-5">
            <i class="bi bi-emoji-neutral fs-1 d-block mb-3"></i>
            <h4>لم يتم الإعلان عن الفائزين بعد</h4>
            <p>تابعونا لمعرفة النتائج قريباً</p>
        </div>
    @endif
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1"></script>
<script>
    @if($winners->isNotEmpty())
        confetti({ particleCount: 150, spread: 70, origin: { y: 0.6 } });
        setTimeout(() => {
            confetti({ particleCount: 100, spread: 100, origin: { y: 0.5, x: 0.3 } });
            confetti({ particleCount: 100, spread: 100, origin: { y: 0.5, x: 0.7 } });
        }, 300);
    @endif
</script>
@endpush