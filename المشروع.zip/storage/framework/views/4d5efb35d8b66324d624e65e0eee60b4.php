

<?php $__env->startSection('title', 'استيراد أسئلة'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4" style="max-width: 700px;">
    <div class="card shadow-sm border-0">
        <div class="card-header bg-white">
            <h4 class="mb-0 fw-bold"><i class="bi bi-upload me-2"></i>استيراد أسئلة من ملف Excel</h4>
        </div>
        <div class="card-body">
            <?php if(session('error')): ?>
                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('admin.questions.import')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="mb-4">
                    <label for="file" class="form-label fw-medium">اختر ملف Excel (xlsx, xls, csv)</label>
                    <input type="file" name="file" id="file" class="form-control <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept=".xlsx,.xls,.csv" required>
                    <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="alert alert-info">
                    <h5 class="alert-heading"><i class="bi bi-info-circle me-2"></i>صيغة الملف المطلوبة:</h5>
                    <p class="mb-0">يجب أن يحتوي الملف على الأعمدة التالية (بنفس الترتيب):</p>
                    <hr>
                    <ul class="mb-0">
                        <li><strong>text</strong> - نص السؤال</li>
                        <li><strong>choice_a</strong> - الخيار الأول</li>
                        <li><strong>choice_b</strong> - الخيار الثاني</li>
                        <li><strong>choice_c</strong> - الخيار الثالث</li>
                        <li><strong>choice_d</strong> - الخيار الرابع</li>
                        <li><strong>correct_choice</strong> - الحرف الصحيح (A,B,C,D)</li>
                        <li><strong>time_sec</strong> - الوقت بالثواني (اختياري)</li>
                    </ul>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" class="btn btn-success">استيراد</button>
                    <a href="<?php echo e(route('admin.questions.index')); ?>" class="btn btn-outline-secondary">إلغاء</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ramadan1-quiz\resources\views\admin\questions\import.blade.php ENDPATH**/ ?>