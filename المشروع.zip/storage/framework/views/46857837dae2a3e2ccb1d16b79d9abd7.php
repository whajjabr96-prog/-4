

<?php $__env->startSection('title', 'إدارة أيام رمضان'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold"><i class="bi bi-calendar2-week-fill me-2"></i>أيام رمضان</h2>
        <a href="<?php echo e(route('admin.competitions.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-circle me-2"></i>إنشاء يوم جديد
        </a>
    </div>

    <?php if(session('ok')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('ok')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm border-0">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>اليوم</th>
                            <th>العنوان</th>
                            <th>البداية</th>
                            <th>النهاية</th>
                            <th>شخصية اليوم</th>
                            <th>الحالة</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $competitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><span class="fw-bold">اليوم <?php echo e($c->day_number); ?></span></td>
                            <td><?php echo e($c->title ?? '—'); ?></td>
                            <td><?php echo e($c->starts_at->format('Y-m-d h:i A')); ?></td>
                            <td><?php echo e($c->ends_at->format('Y-m-d h:i A')); ?></td>
                            <td>
                                <?php if($c->personality_enabled): ?>
                                    <span class="badge bg-info" data-bs-toggle="tooltip" title="<?php echo e($c->personality_name); ?>">
                                        <i class="bi bi-star-fill text-warning me-1"></i>مفعلة
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">غير مفعلة</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo e($c->is_published ? 'success' : 'secondary'); ?>">
                                    <?php echo e($c->is_published ? 'منشور' : 'غير منشور'); ?>

                                </span>
                            </td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="<?php echo e(route('admin.competitions.edit', $c)); ?>" class="btn btn-sm btn-outline-primary" title="تعديل">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.competitions.winners.index', $c)); ?>" class="btn btn-sm btn-outline-warning" title="الفائزين">
                                        <i class="bi bi-trophy"></i>
                                    </a>
                                    <form method="POST" action="<?php echo e(route('admin.competitions.toggle', $c)); ?>" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <button class="btn btn-sm btn-outline-<?php echo e($c->is_published ? 'secondary' : 'success'); ?>" title="<?php echo e($c->is_published ? 'إلغاء النشر' : 'نشر'); ?>">
                                            <i class="bi bi-<?php echo e($c->is_published ? 'eye-slash' : 'eye'); ?>"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    // تفعيل tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl)
    })
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ramadan1-quiz\resources\views/admin/competitions/index.blade.php ENDPATH**/ ?>