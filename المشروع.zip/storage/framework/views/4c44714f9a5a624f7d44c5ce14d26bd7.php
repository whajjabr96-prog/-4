

<?php $__env->startSection('title', 'تعديل المستخدم'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <h2 class="fw-bold mb-4"><i class="bi bi-person-gear me-2"></i>تعديل بيانات المستخدم</h2>

    <div class="card shadow-sm border-0">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.users.update', $user)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">الاسم</label>
                        <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $user->name)); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">البريد الإلكتروني</label>
                        <input type="email" name="email" class="form-control" value="<?php echo e(old('email', $user->email)); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">رقم الهاتف</label>
                        <input type="text" name="phone" class="form-control" value="<?php echo e(old('phone', $user->phone)); ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">التخصص</label>
                        <input type="text" name="major" class="form-control" value="<?php echo e(old('major', $user->major)); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">رقم القيد</label>
                        <input type="text" name="student_no" class="form-control" value="<?php echo e(old('student_no', $user->student_no)); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">الدور</label>
                        <select name="role" class="form-select">
                            <option value="student" <?php echo e($user->role == 'student' ? 'selected' : ''); ?>>طالب</option>
                            <option value="editor" <?php echo e($user->role == 'editor' ? 'selected' : ''); ?>>محرر</option>
                            <option value="supervisor" <?php echo e($user->role == 'supervisor' ? 'selected' : ''); ?>>مشرف</option>
                            <option value="admin" <?php echo e($user->role == 'admin' ? 'selected' : ''); ?>>مدير</option>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">الحالة</label>
                        <select name="status" class="form-select">
                            <option value="pending" <?php echo e($user->status == 'pending' ? 'selected' : ''); ?>>قيد المراجعة</option>
                            <option value="approved" <?php echo e($user->status == 'approved' ? 'selected' : ''); ?>>مقبول</option>
                            <option value="rejected" <?php echo e($user->status == 'rejected' ? 'selected' : ''); ?>>مرفوض</option>
                        </select>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">حفظ التغييرات</button>
                <a href="<?php echo e(route('admin.users')); ?>" class="btn btn-secondary">إلغاء</a>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ramadan1-quiz\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>