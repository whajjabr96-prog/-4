

<?php $__env->startSection('title', 'إدارة المستخدمين'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold"><i class="bi bi-people-fill me-2"></i>إدارة المستخدمين</h2>
        <?php if(auth()->user()->role == 'admin'): ?>
            <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary">
                <i class="bi bi-plus-circle me-2"></i>إضافة مستخدم جديد
            </a>
        <?php endif; ?>
    </div>

    <?php if(session('ok')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('ok')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- شريط البحث والتبويبات -->
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body">
            <form class="row g-3 mb-3" method="GET" action="<?php echo e(route('admin.users')); ?>">
                <div class="col-md-9">
                    <div class="input-group">
                        <span class="input-group-text bg-white"><i class="bi bi-search"></i></span>
                        <input class="form-control" name="q" value="<?php echo e($q ?? ''); ?>" placeholder="بحث: اسم / إيميل / هاتف / رقم قيد">
                    </div>
                </div>
                <div class="col-md-3 d-grid">
                    <button class="btn btn-primary" type="submit">بحث</button>
                </div>
            </form>

            <ul class="nav nav-tabs" id="userTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <button class="nav-link active" id="pending-tab" data-bs-toggle="tab" data-bs-target="#pending" type="button" role="tab">قيد المراجعة</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="approved-tab" data-bs-toggle="tab" data-bs-target="#approved" type="button" role="tab">مقبولون</button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link" id="rejected-tab" data-bs-toggle="tab" data-bs-target="#rejected" type="button" role="tab">مرفوضون</button>
                </li>
            </ul>
        </div>
    </div>

    <div class="tab-content">
        <!-- Pending -->
        <div class="tab-pane fade show active" id="pending" role="tabpanel">
            <?php echo $__env->make('admin.users.partials.table', ['rows' => $pending ?? [], 'mode' => 'pending'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="mt-3"><?php echo e($pending->withQueryString()->links() ?? ''); ?></div>
        </div>

        <!-- Approved -->
        <div class="tab-pane fade" id="approved" role="tabpanel">
            <?php echo $__env->make('admin.users.partials.table', ['rows' => $approved ?? [], 'mode' => 'approved'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="mt-3"><?php echo e($approved->withQueryString()->links('pagination::bootstrap-5') ?? ''); ?></div>
        </div>

        <!-- Rejected -->
        <div class="tab-pane fade" id="rejected" role="tabpanel">
            <?php echo $__env->make('admin.users.partials.table', ['rows' => $rejected ?? [], 'mode' => 'rejected'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="mt-3"><?php echo e($rejected->withQueryString()->links('pagination::bootstrap-5') ?? ''); ?></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ramadan1-quiz\resources\views\admin\users\index.blade.php ENDPATH**/ ?>