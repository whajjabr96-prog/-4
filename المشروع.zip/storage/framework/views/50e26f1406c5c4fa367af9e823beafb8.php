

<?php $__env->startSection('title', 'فائزو اليوم ' . $competition->day_number); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold"><i class="bi bi-trophy-fill me-2"></i>فائزو اليوم <?php echo e($competition->day_number); ?></h2>
        <div>
            <?php if(!$competition->results_published): ?>
                <form method="POST" action="<?php echo e(route('admin.competitions.winners.publish', $competition)); ?>" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-success" onclick="return confirm('سيتم نشر النتائج للمستخدمين. هل أنت متأكد؟')">
                        <i class="bi bi-megaphone me-1"></i>نشر النتائج
                    </button>
                </form>
            <?php else: ?>
                <span class="badge bg-success p-2">منشور</span>
            <?php endif; ?>
            <a href="<?php echo e(route('admin.competitions.winners.select', $competition)); ?>" class="btn btn-primary">
                <i class="bi bi-pencil-square me-2"></i>اختيار الفائزين يدويًا
            </a>
            <a href="<?php echo e(route('admin.competitions')); ?>" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-right me-1"></i>عودة
            </a>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="card shadow-sm border-0">
        <div class="card-header bg-transparent">
            <span><?php echo e($competition->title ?? ''); ?></span>
        </div>
        <div class="card-body">
            <?php if($winners->isEmpty()): ?>
                <p class="text-muted text-center py-4">لم يتم تحديد فائزين بعد.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr><th>المركز</th><th>الاسم</th><th>ملاحظات</th></tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $winners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $winner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php if($winner->rank == 1): ?> 🥇
                                        <?php elseif($winner->rank == 2): ?> 🥈
                                        <?php elseif($winner->rank == 3): ?> 🥉
                                        <?php else: ?> <?php echo e($winner->rank); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($winner->user->name); ?></td>
                                    <td><?php echo e($winner->note); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ramadan1-quiz\resources\views\admin\winners\index.blade.php ENDPATH**/ ?>