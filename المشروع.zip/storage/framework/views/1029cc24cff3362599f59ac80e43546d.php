

<?php $__env->startSection('title', 'اختيار الفائزين - اليوم ' . $competition->day_number); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .winner-row.selected {
        background-color: rgba(40, 167, 69, 0.1);
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold"><i class="bi bi-trophy-fill me-2"></i>اختيار الفائزين لليوم <?php echo e($competition->day_number); ?></h2>
        <a href="<?php echo e(route('admin.competitions.winners.index', $competition)); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-right me-1"></i>عودة
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <?php if($attempts->isEmpty()): ?>
        <div class="alert alert-warning">لا توجد محاولات مكتملة لهذا اليوم.</div>
    <?php else: ?>
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.competitions.winners.store', $competition)); ?>" id="winnersForm">
                    <?php echo csrf_field(); ?>

                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead class="table-light">
                                <tr>
                                    <th>الترتيب</th>
                                    <th>الاسم</th>
                                    <th>الدرجة</th>
                                    <th>وقت الإنهاء</th>
                                    <th>اختيار</th>
                                    <th>المركز</th>
                                    <th>ملاحظات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $attempts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $attempt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="winner-row" id="row-<?php echo e($attempt->id); ?>">
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($attempt->user->name); ?></td>
                                    <td><?php echo e($attempt->score); ?></td>
                                    <td><?php echo e($attempt->submitted_at->format('H:i:s')); ?></td>
                                    <td>
                                        <input type="checkbox" class="form-check-input select-winner" 
                                               data-user-id="<?php echo e($attempt->user_id); ?>" 
                                               data-attempt-id="<?php echo e($attempt->id); ?>">
                                    </td>
                                    <td>
                                        <select name="winners[<?php echo e($index); ?>][rank]" class="form-select form-select-sm rank-select" disabled>
                                            <option value="">--</option>
                                            <?php for($i=1; $i<=10; $i++): ?>
                                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                            <?php endfor; ?>
                                        </select>
                                        <input type="hidden" name="winners[<?php echo e($index); ?>][user_id]" class="user-id-input" value="<?php echo e($attempt->user_id); ?>" disabled>
                                    </td>
                                    <td>
                                        <input type="text" name="winners[<?php echo e($index); ?>][note]" class="form-control form-control-sm note-input" placeholder="اختياري" disabled>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-4">
                        <button type="submit" class="btn btn-success" id="saveBtn">
                            <i class="bi bi-check-circle me-2"></i>حفظ الفائزين
                        </button>
                        <a href="<?php echo e(route('admin.competitions.winners.index', $competition)); ?>" class="btn btn-secondary">إلغاء</a>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const checkboxes = document.querySelectorAll('.select-winner');
        
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                const row = this.closest('tr');
                const rankSelect = row.querySelector('.rank-select');
                const noteInput = row.querySelector('.note-input');
                const userIdInput = row.querySelector('.user-id-input');
                
                if (this.checked) {
                    row.classList.add('selected');
                    rankSelect.disabled = false;
                    noteInput.disabled = false;
                    userIdInput.disabled = false;
                } else {
                    row.classList.remove('selected');
                    rankSelect.disabled = true;
                    noteInput.disabled = true;
                    userIdInput.disabled = true;
                }
            });
        });

        // التحقق قبل الإرسال من تحديد المراكز لكل من تم اختياره
        document.getElementById('winnersForm').addEventListener('submit', function(e) {
            let valid = true;
            document.querySelectorAll('.select-winner:checked').forEach(checkbox => {
                const row = checkbox.closest('tr');
                const rankSelect = row.querySelector('.rank-select');
                if (!rankSelect.value) {
                    valid = false;
                    alert('يرجى تحديد المركز لكل من تم اختياره');
                    e.preventDefault();
                }
            });
            
            if (!valid) e.preventDefault();
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ramadan1-quiz\resources\views\admin\winners\select.blade.php ENDPATH**/ ?>