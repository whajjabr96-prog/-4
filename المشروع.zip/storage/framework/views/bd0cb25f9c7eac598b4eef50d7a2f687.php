

<?php $__env->startSection('title', 'الأسئلة'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold"><i class="bi bi-patch-question-fill me-2"></i>الأسئلة</h2>
        <div>
            <a href="<?php echo e(route('admin.questions.create')); ?>" class="btn btn-primary">
                <i class="bi bi-plus-circle me-2"></i>إضافة سؤال
            </a>
            <a href="<?php echo e(route('admin.questions.import_to_competition.form')); ?>" class="btn btn-warning">
                <i class="bi bi-upload me-2"></i>استيراد ليوم محدد
            </a>
            <a href="<?php echo e(route('admin.questions.import.form')); ?>" class="btn btn-success">
                <i class="bi bi-upload me-2"></i>استيراد عام
            </a>
            <a href="<?php echo e(route('admin.questions.export')); ?>" class="btn btn-info">
                <i class="bi bi-download me-2"></i>تصدير
            </a>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- فلتر -->
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-4">
                    <label for="competition_id" class="form-label fw-medium">تصفية حسب اليوم:</label>
                    <select name="competition_id" id="competition_id" class="form-select" onchange="this.form.submit()">
                        <option value="">جميع الأسئلة</option>
                        <?php $__currentLoopData = $competitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($comp->id); ?>" <?php echo e($competitionId == $comp->id ? 'selected' : ''); ?>>
                                اليوم <?php echo e($comp->day_number); ?> - <?php echo e($comp->title ?? 'بدون عنوان'); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </form>
        </div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>السؤال</th>
                            <th>الخيارات</th>
                            <th>الإجابة الصحيحة</th>
                            <th>الوقت (ث)</th>
                            <th>شخصية</th>
                            <th>الأيام المرتبط بها</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($question->id); ?></td>
                                <td><?php echo e(Str::limit($question->text, 50)); ?></td>
                                <td>
                                    <small>
                                        A: <?php echo e(Str::limit($question->choice_a, 20)); ?><br>
                                        B: <?php echo e(Str::limit($question->choice_b, 20)); ?><br>
                                        C: <?php echo e(Str::limit($question->choice_c, 20)); ?><br>
                                        D: <?php echo e(Str::limit($question->choice_d, 20)); ?>

                                    </small>
                                </td>
                                <td><span class="badge bg-success"><?php echo e($question->correct_choice); ?></span></td>
                                <td><?php echo e($question->time_sec ?? '—'); ?></td>
                                <td>
                                    <?php if($question->is_personality): ?>
                                        <span class="badge bg-info">نعم</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">لا</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php $__currentLoopData = $question->competitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge bg-info me-1"><?php echo e($comp->day_number); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="<?php echo e(route('admin.questions.edit', $question)); ?>" class="btn btn-sm btn-outline-warning" title="تعديل">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <form method="POST" action="<?php echo e(route('admin.questions.destroy', $question)); ?>" class="d-inline"
                                              onsubmit="return confirm('هل أنت متأكد من حذف هذا السؤال؟');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-sm btn-outline-danger" type="submit" title="حذف">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted py-4">لا توجد أسئلة.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($questions->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ramadan1-quiz\resources\views/admin/questions/index.blade.php ENDPATH**/ ?>