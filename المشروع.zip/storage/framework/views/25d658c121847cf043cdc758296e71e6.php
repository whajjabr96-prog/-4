

<?php $__env->startSection('title', 'الملف الشخصي'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-lg border-0 rounded-4 overflow-hidden">
                <div class="card-header bg-primary text-white py-3">
                    <h4 class="mb-0 fw-bold"><i class="bi bi-person-circle me-2"></i>الملف الشخصي</h4>
                </div>
                <div class="card-body p-4">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                    <?php endif; ?>

                    <?php if(isset($pendingRequest) && $pendingRequest): ?>
                        <div class="alert alert-warning">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            لديك طلب تعديل قيد المراجعة (تم إرساله في <?php echo e($pendingRequest->created_at->format('Y-m-d H:i')); ?>). يرجى الانتظار.
                        </div>
                    <?php endif; ?>

                    <table class="table table-borderless">
                        <tr>
                            <th width="200">الاسم</th>
                            <td class="fw-bold"><?php echo e($user->name); ?></td>
                        </tr>
                        <tr>
                            <th>البريد الإلكتروني</th>
                            <td><?php echo e($user->email); ?></td>
                        </tr>
                        <tr>
                            <th>رقم الهاتف</th>
                            <td><?php echo e($user->phone); ?></td>
                        </tr>
                        <tr>
                            <th>التخصص</th>
                            <td><?php echo e($user->major ?? '—'); ?></td>
                        </tr>
                        <tr>
                            <th>رقم القيد</th>
                            <td><?php echo e($user->student_no ?? '—'); ?></td>
                        </tr>
                        <tr>
                            <th>الدور</th>
                            <td>
                                <?php if($user->role == 'admin'): ?> <span class="badge bg-danger">مدير</span>
                                <?php elseif($user->role == 'supervisor'): ?> <span class="badge bg-warning text-dark">مشرف</span>
                                <?php elseif($user->role == 'editor'): ?> <span class="badge bg-info">محرر</span>
                                <?php else: ?> <span class="badge bg-secondary">طالب</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr>
                            <th>حالة الحساب</th>
                            <td>
                                <?php if($user->status == 'approved'): ?> <span class="badge bg-success">مقبول</span>
                                <?php elseif($user->status == 'pending'): ?> <span class="badge bg-warning">قيد المراجعة</span>
                                <?php else: ?> <span class="badge bg-danger">مرفوض</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </table>

                    <?php if(!isset($pendingRequest) || !$pendingRequest): ?>
                        <a href="<?php echo e(route('student.profile.edit')); ?>" class="btn btn-primary mt-3">
                            <i class="bi bi-pencil me-2"></i>طلب تعديل البيانات
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ramadan1-quiz\resources\views/student/profile.blade.php ENDPATH**/ ?>