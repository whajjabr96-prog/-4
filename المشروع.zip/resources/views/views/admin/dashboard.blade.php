@extends('layouts.app')

@section('title', 'لوحة التحكم')

@section('content')
<div class="container-fluid py-4">
    <h2 class="fw-bold mb-4"><i class="bi bi-grid-3x3-gap-fill me-2"></i>لوحة التحكم</h2>

    <div class="row g-4 mb-4">
        <div class="col-md-6 col-lg-3">
            <div class="card bg-primary text-white h-100 border-0 shadow">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50">إجمالي المستخدمين</h6>
                            <h3 class="mb-0">{{ $totalUsers }}</h3>
                        </div>
                        <i class="bi bi-people-fill fs-1 opacity-50"></i>
                    </div>
                    <small class="text-white-50">{{ $pendingUsers }} في انتظار الموافقة</small>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-3">
            <div class="card bg-success text-white h-100 border-0 shadow">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50">المسابقات</h6>
                            <h3 class="mb-0">{{ $totalCompetitions }}</h3>
                        </div>
                        <i class="bi bi-calendar2-week-fill fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-3">
            <div class="card bg-info text-white h-100 border-0 shadow">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50">إجمالي المحاولات</h6>
                            <h3 class="mb-0">{{ $totalAttempts }}</h3>
                        </div>
                        <i class="bi bi-clock-history fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-lg-3">
            <div class="card bg-warning text-white h-100 border-0 shadow">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="text-white-50">يختبرون الآن</h6>
                            <h3 class="mb-0">{{ $nowTesting->count() }}</h3>
                        </div>
                        <i class="bi bi-person-workspace fs-1 opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-6 mb-4">
            <div class="card h-100 shadow">
                <div class="card-header bg-transparent fw-bold">
                    <i class="bi bi-clock-history me-2"></i>آخر 10 محاولات مكتملة
                </div>
                <div class="card-body">
                    <table class="table table-hover">
                        <thead>
                            <tr><th>المستخدم</th><th>اليوم</th><th>الدرجة</th><th>الوقت</th></tr>
                        </thead>
                        <tbody>
                            @forelse($recentAttempts as $attempt)
                                <tr>
                                    <td>{{ $attempt->user->name }}</td>
                                    <td>{{ $attempt->competition->day_number }}</td>
                                    <td>{{ $attempt->score }}</td>
                                    <td>{{ $attempt->submitted_at->diffForHumans() }}</td>
                                </tr>
                            @empty
                                <tr><td colspan="4" class="text-muted">لا توجد محاولات</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-lg-6 mb-4">
            <div class="card h-100 shadow border-warning">
                <div class="card-header bg-warning text-white fw-bold">
                    <i class="bi bi-person-workspace me-2"></i>يختبرون الآن
                </div>
                <div class="card-body">
                    <table class="table table-hover">
                        <thead>
                            <tr><th>المستخدم</th><th>اليوم</th><th>بدأ في</th></tr>
                        </thead>
                        <tbody>
                            @forelse($nowTesting as $attempt)
                                <tr>
                                    <td>{{ $attempt->user->name }}</td>
                                    <td>{{ $attempt->competition->day_number }}</td>
                                    <td>{{ $attempt->started_at->diffForHumans() }}</td>
                                </tr>
                            @empty
                                <tr><td colspan="3" class="text-muted">لا يوجد أحد يختبر الآن</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12 mb-4">
            <div class="card shadow">
                <div class="card-header bg-transparent fw-bold">
                    <h5 class="mb-0">عدد المشاركات لكل يوم</h5>
                </div>
                <div class="card-body">
                    <canvas id="dailyChart" height="100"></canvas>
                </div>
            </div>
        </div>
    </div>

    @if($todayCompetition)
    <div class="row">
        <div class="col-12">
            <div class="card shadow">
                <div class="card-header bg-transparent d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">أفضل نتائج اليوم {{ $todayCompetition->day_number }}</h5>
                    <a href="{{ route('admin.competitions.winners.index', $todayCompetition) }}" class="btn btn-sm btn-primary">
                        إدارة الفائزين
                    </a>
                </div>
                <div class="card-body">
                    <table class="table table-sm">
                        <thead>
                            <tr><th>#</th><th>الاسم</th><th>الدرجة</th></tr>
                        </thead>
                        <tbody>
                            @foreach($topScores as $index => $attempt)
                                <tr>
                                    <td>{{ $index + 1 }}</td>
                                    <td>{{ $attempt->user->name }}</td>
                                    <td>{{ $attempt->score }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    @endif
</div>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const dailyStats = @json($dailyStats);
    new Chart(document.getElementById('dailyChart'), {
        type: 'bar',
        data: {
            labels: dailyStats.map(item => 'يوم ' + item.day_number),
            datasets: [{
                label: 'عدد المحاولات',
                data: dailyStats.map(item => item.attempts_count || 0),
                backgroundColor: 'rgba(247, 183, 49, 0.7)',
                borderRadius: 8
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } }
        }
    });
</script>
@endpush