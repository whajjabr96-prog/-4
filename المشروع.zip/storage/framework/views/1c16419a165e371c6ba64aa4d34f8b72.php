

<?php $__env->startSection('title', 'تعليمات المسابقة'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <div class="card shadow-lg border-0">
                <div class="card-header bg-warning text-dark text-center py-4">
                    <h2 class="mb-0"><i class="bi bi-question-circle-fill me-2"></i>تعليمات المسابقة</h2>
                </div>
                <div class="card-body p-5">
                    <div class="text-center mb-5">
                        <i class="bi bi-lightbulb text-warning display-1"></i>
                        <h3 class="mt-3">كيف تشارك في المسابقة؟</h3>
                    </div>

                    <div class="accordion" id="instructionsAccordion">
                        <!-- التسجيل -->
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse1">
                                    <i class="bi bi-person-plus-fill me-2 text-primary"></i>
                                    ١. التسجيل في الموقع
                                </button>
                            </h2>
                            <div id="collapse1" class="accordion-collapse collapse show" data-bs-parent="#instructionsAccordion">
                                <div class="accordion-body">
                                    <ul>
                                        <li>قم بإنشاء حساب جديد عبر صفحة التسجيل.</li>
                                        <li>أدخل بياناتك الشخصية (الاسم، البريد الإلكتروني، رقم الهاتف، التخصص، رقم القيد اختياري).</li>
                                        <li>بعد التسجيل، سيكون حسابك قيد المراجعة من قبل الإدارة. ستتلقى إشعاراً عند قبول حسابك.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!-- مواعيد المسابقة -->
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse2">
                                    <i class="bi bi-clock-history me-2 text-success"></i>
                                    ٢. مواعيد المسابقة
                                </button>
                            </h2>
                            <div id="collapse2" class="accordion-collapse collapse" data-bs-parent="#instructionsAccordion">
                                <div class="accordion-body">
                                    <ul>
                                        <li><strong>الوقت:</strong> تفتح المسابقة يومياً من الساعة 9:00 مساءً حتى 11:00 مساءً.</li>
                                        <li><strong>المدة:</strong> لا يمكن الدخول قبل أو بعد هذا الوقت.</li>
                                        <li><strong>عدد الأسئلة:</strong> يختلف من يوم لآخر (عادة 20-30 سؤال).</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!-- طريقة الاختبار -->
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse3">
                                    <i class="bi bi-pencil-square me-2 text-info"></i>
                                    ٣. طريقة الاختبار
                                </button>
                            </h2>
                            <div id="collapse3" class="accordion-collapse collapse" data-bs-parent="#instructionsAccordion">
                                <div class="accordion-body">
                                    <ul>
                                        <li>اختر اليوم المطلوب من الصفحة الرئيسية.</li>
                                        <li>سيظهر لك سؤال مع أربعة خيارات.</li>
                                        <li>لديك <strong>30 ثانية</strong> لكل سؤال (قد يختلف الوقت حسب إعدادات اليوم).</li>
                                        <li>اختر إجابتك ثم اضغط على "تأكيد الإجابة".</li>
                                        <li><span class="text-danger">تنبيه:</span> لا يمكنك العودة للسؤال السابق بعد تأكيد الإجابة.</li>
                                        <li>إذا انتهى الوقت دون إجابة، ينتقل السؤال تلقائياً ويتم احتساب الإجابة خاطئة.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!-- سؤال شخصية اليوم -->
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse4">
                                    <i class="bi bi-star-fill me-2 text-warning"></i>
                                    ٤. شخصية اليوم (السؤال الخاص)
                                </button>
                            </h2>
                            <div id="collapse4" class="accordion-collapse collapse" data-bs-parent="#instructionsAccordion">
                                <div class="accordion-body">
                                    <ul>
                                        <li>في نهاية كل اختبار، هناك سؤال خاص عن شخصية معينة.</li>
                                        <li>قبل الإجابة، تظهر صورة الشخصية مشوشة ولا يمكن رؤيتها.</li>
                                        <li>بعد الإجابة (سواء صحيحة أو خاطئة)، ستظهر الصورة واضحة مع اسم ووصف الشخصية.</li>
                                        <li>إذا كانت إجابتك صحيحة، يظهر شريط أخضر مع علامة صح. وإذا خاطئة يظهر شريط أحمر.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!-- النتائج -->
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse5">
                                    <i class="bi bi-bar-chart-fill me-2 text-secondary"></i>
                                    ٥. النتائج والفائزون
                                </button>
                            </h2>
                            <div id="collapse5" class="accordion-collapse collapse" data-bs-parent="#instructionsAccordion">
                                <div class="accordion-body">
                                    <ul>
                                        <li>بعد انتهاء الاختبار، تظهر صفحة النتيجة مباشرة مع عدد الإجابات الصحيحة والخاطئة والفارغة.</li>
                                        <li>يتم إعلان الفائزين لكل يوم بعد مراجعة الإدارة.</li>
                                        <li>يمكنك الاطلاع على الفائزين من خلال الصفحة الرئيسية، بعد أن يتم نشر النتائج.</li>
                                        <li>سيظهر تأثير احتفالي (كونفيتي) عند عرض الفائزين.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <!-- نصائح مهمة -->
                        <div class="accordion-item">
                            <h2 class="accordion-header">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse6">
                                    <i class="bi bi-exclamation-triangle-fill me-2 text-danger"></i>
                                    ٦. نصائح مهمة
                                </button>
                            </h2>
                            <div id="collapse6" class="accordion-collapse collapse" data-bs-parent="#instructionsAccordion">
                                <div class="accordion-body">
                                    <ul>
                                        <li>تأكد من استقرار اتصالك بالإنترنت قبل بدء الاختبار.</li>
                                        <li>لا تقم بتحديث الصفحة أو الضغط على زر الرجوع أثناء الاختبار.</li>
                                        <li>يمكنك الدخول للاختبار مرة واحدة فقط لكل يوم.</li>
                                        <li>إذا واجهت مشكلة تقنية، تواصل مع إدارة الموقع.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="alert alert-info mt-5">
                        <i class="bi bi-chat-dots-fill me-2"></i>
                        للمزيد من الاستفسارات، يمكنك التواصل مع إدارة الكلية عبر البريد الإلكتروني: <strong>info@college.edu</strong>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ramadan1-quiz\resources\views/pages/instructions.blade.php ENDPATH**/ ?>