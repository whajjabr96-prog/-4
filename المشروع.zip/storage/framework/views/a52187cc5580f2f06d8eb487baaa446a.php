

<?php $__env->startSection('title', 'استيراد أسئلة ليوم محدد'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold"><i class="bi bi-upload me-2"></i>استيراد أسئلة ليوم محدد</h2>
        <a href="<?php echo e(route('admin.questions.index')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-right me-1"></i>عودة
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm border-0">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.questions.import_to_competition')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="competition_id" class="form-label">اختر اليوم <span class="text-danger">*</span></label>
                        <select name="competition_id" id="competition_id" class="form-select" required>
                            <option value="">-- اختر اليوم --</option>
                            <?php $__currentLoopData = $competitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($comp->id); ?>">
                                    اليوم <?php echo e($comp->day_number); ?> - <?php echo e($comp->title ?? ''); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div class="form-text">سيتم إضافة الأسئلة إلى هذا اليوم مع الحفاظ على ترتيب الأسئلة الحالي.</div>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label for="file" class="form-label">ملف Excel <span class="text-danger">*</span></label>
                        <input type="file" name="file" id="file" class="form-control" accept=".xlsx,.xls,.csv" required>
                        <div class="form-text">
                            <i class="bi bi-info-circle"></i>
                            الملف يجب أن يحتوي على الأعمدة: text, choice_a, choice_b, choice_c, choice_d, correct_choice, time_sec (اختياري)
                        </div>
                    </div>
                </div>

                <div class="alert alert-info">
                    <i class="bi bi-lightbulb me-2"></i>
                    سيتم إضافة الأسئلة إلى اليوم المحدد مع ترتيب تلقائي حسب ترتيبها في الملف (بعد الأسئلة الموجودة حالياً).
                </div>

                <button type="submit" class="btn btn-warning">
                    <i class="bi bi-upload me-2"></i>استيراد وربط باليوم
                </button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ramadan1-quiz\resources\views/admin/questions/import_to_competition.blade.php ENDPATH**/ ?>