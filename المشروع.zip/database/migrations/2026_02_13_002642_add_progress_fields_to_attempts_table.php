<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // لا شيء - الأعمدة موجودة مسبقًا في create_attempts_table
    }

    public function down(): void
    {
        // لا شيء
    }
};
