

<?php $__env->startSection('title', 'طلبات تعديل الملفات الشخصية'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <h2 class="fw-bold mb-4"><i class="bi bi-person-badge me-2"></i>طلبات تعديل الملفات الشخصية</h2>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm border-0">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>#</th>
                            <th>المستخدم</th>
                            <th>البيانات الحالية</th>
                            <th>البيانات الجديدة</th>
                            <th>الحالة</th>
                            <th>تاريخ الطلب</th>
                            <th>الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($req->id); ?></td>
                                <td><?php echo e($req->user->name ?? '—'); ?></td>
                                <td>
                                    <small>
                                        <?php if($req->old_data): ?>
                                            <?php echo e($req->old_data['name'] ?? ''); ?><br>
                                            <?php echo e($req->old_data['email'] ?? ''); ?>

                                        <?php else: ?>
                                            —
                                        <?php endif; ?>
                                    </small>
                                </td>
                                <td>
                                    <small>
                                        <?php if($req->new_data): ?>
                                            <?php echo e($req->new_data['name'] ?? ''); ?><br>
                                            <?php echo e($req->new_data['email'] ?? ''); ?>

                                        <?php else: ?>
                                            —
                                        <?php endif; ?>
                                    </small>
                                </td>
                                <td>
                                    <?php if($req->status == 'pending'): ?>
                                        <span class="badge bg-warning">قيد المراجعة</span>
                                    <?php elseif($req->status == 'approved'): ?>
                                        <span class="badge bg-success">مقبول</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">مرفوض</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($req->created_at->format('Y-m-d H:i')); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.profile_requests.show', $req)); ?>" class="btn btn-sm btn-primary">
                                        <i class="bi bi-eye"></i> عرض
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center text-muted py-4">لا توجد طلبات.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($requests->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ramadan1-quiz\resources\views/admin/profile_requests/index.blade.php ENDPATH**/ ?>