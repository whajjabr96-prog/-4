

<?php $__env->startSection('title', 'عرض المستخدم'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold"><i class="bi bi-person-badge me-2"></i>بيانات المستخدم</h2>
        <a href="<?php echo e(route('admin.users')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-right me-1"></i>عودة
        </a>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-body">
            <table class="table table-bordered">
                <tr>
                    <th width="200">الاسم</th>
                    <td><?php echo e($user->name); ?></td>
                </tr>
                <tr>
                    <th>البريد الإلكتروني</th>
                    <td><?php echo e($user->email); ?></td>
                </tr>
                <tr>
                    <th>رقم الهاتف</th>
                    <td><?php echo e($user->phone); ?></td>
                </tr>
                <tr>
                    <th>التخصص</th>
                    <td><?php echo e($user->major ?? '—'); ?></td>
                </tr>
                <tr>
                    <th>رقم القيد</th>
                    <td><?php echo e($user->student_no ?? '—'); ?></td>
                </tr>
                <tr>
                    <th>الدور</th>
                    <td>
                        <?php if($user->role == 'admin'): ?>
                            <span class="badge bg-danger">مدير</span>
                        <?php elseif($user->role == 'supervisor'): ?>
                            <span class="badge bg-warning text-dark">مشرف</span>
                        <?php elseif($user->role == 'editor'): ?>
                            <span class="badge bg-info">محرر</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">طالب</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th>الحالة</th>
                    <td>
                        <?php if($user->status == 'approved'): ?>
                            <span class="badge bg-success">مقبول</span>
                        <?php elseif($user->status == 'pending'): ?>
                            <span class="badge bg-warning text-dark">قيد المراجعة</span>
                        <?php else: ?>
                            <span class="badge bg-danger">مرفوض</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th>تاريخ التسجيل</th>
                    <td><?php echo e($user->created_at->format('Y-m-d H:i')); ?></td>
                </tr>
                <?php if($user->approved_at): ?>
                <tr>
                    <th>تاريخ القبول</th>
                    <td><?php echo e($user->approved_at->format('Y-m-d H:i')); ?></td>
                </tr>
                <?php endif; ?>
            </table>

            <?php if(auth()->user()->role == 'admin'): ?>
                <div class="mt-4">
                    <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="btn btn-primary">
                        <i class="bi bi-pencil me-2"></i>تعديل
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ramadan1-quiz\resources\views/admin/users/show.blade.php ENDPATH**/ ?>