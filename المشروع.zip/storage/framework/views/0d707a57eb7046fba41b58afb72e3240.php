<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>الرئيسية</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-white">
  <div class="container py-5">
    <div class="d-flex justify-content-between align-items-center">
      <h3 class="mb-0">مرحبًا، <?php echo e(auth()->user()->name); ?></h3>

      <form method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button class="btn btn-outline-light btn-sm">تسجيل خروج</button>
      </form>
    </div>

    <div class="mt-4 p-4 bg-secondary rounded">
      <div>حالة حسابك: <b><?php echo e(auth()->user()->status); ?></b></div>
      <div class="text-white-50 mt-2">
        لاحقًا هنا سنعرض أيام رمضان والاختبارات.
      </div>
    </div>
  </div>
</body>
</html>
<?php /**PATH C:\laragon\www\ramadan1-quiz\resources\views/home.blade.php ENDPATH**/ ?>