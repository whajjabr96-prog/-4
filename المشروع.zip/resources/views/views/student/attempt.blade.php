<!doctype html>
<html lang="ar" dir="rtl" data-bs-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', config('app.name'))</title>

    <!-- Bootstrap 5 RTL + Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <!-- Toastr CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    
    <!-- Google Fonts - Tajawal -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;900&display=swap" rel="stylesheet">

    <style>
        :root {
            --ramadan-gold: #f7b731;
            --ramadan-night: #1e2a47;
            --ramadan-lantern: #ffd966;
            --bs-primary: #0d6efd;
            --bs-primary-rgb: 13, 110, 253;
        }

        body {
            font-family: 'Tajawal', sans-serif;
            background: linear-gradient(135deg, #0b1a33 0%, #1a2f4f 100%);
            transition: background-color 0.3s ease, color 0.3s ease;
            position: relative;
            min-height: 100vh;
            margin: 0;
            overflow-x: hidden;
        }

        /* الخلفية المتحركة */
        .stars, .twinkling {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            width: 100%;
            height: 100%;
            display: block;
            pointer-events: none;
            z-index: -1;
        }

        .stars {
            background: #000 url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMDAiIGhlaWdodD0iMzAwIj48Y2lyY2xlIGN4PSI2IiBjeT0iMTQiIHI9IjEiIGZpbGw9IndoaXRlIiAvPjxjaXJjbGUgY3g9IjE2MCIgY3k9IjYwIiByPSIxIiBmaWxsPSJ3aGl0ZSIgLz48Y2lyY2xlIGN4PSI0MCIgY3k9IjIxMCIgcj0iMSIgZmlsbD0id2hpdGUiIC8+PC9zdmc+');
            background-size: 200px 200px;
            animation: starsAnim 200s linear infinite;
            opacity: 0.5;
        }

        .twinkling {
            background: transparent url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIzMDAiIGhlaWdodD0iMzAwIj48Y2lyY2xlIGN4PSIxMDAiIGN5PSI1MCIgcj0iMiIgZmlsbD0iI2ZmZmZmZiIgLz48L3N2Zz4=');
            background-size: 200px 200px;
            animation: twinklingAnim 4s linear infinite;
            opacity: 0.5;
        }

        @keyframes starsAnim {
            from { background-position: 0 0; }
            to { background-position: 0 -10000px; }
        }

        @keyframes twinklingAnim {
            0% { opacity: 0.2; }
            50% { opacity: 0.8; }
            100% { opacity: 0.2; }
        }

        /* فوانيس متحركة */
        .lantern {
            position: fixed;
            top: 20px;
            left: 20px;
            width: 60px;
            height: 80px;
            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23f7b731"><path d="M12 2C8 2 4 5 4 9c0 4 8 13 8 13s8-9 8-13c0-4-4-7-8-7z"/></svg>') no-repeat center;
            background-size: contain;
            animation: swing 3s infinite ease-in-out;
            filter: drop-shadow(0 0 10px rgba(247, 183, 49, 0.5));
            z-index: 10;
            pointer-events: none;
            transform-origin: top center;
        }

        .lantern.right {
            left: auto;
            right: 20px;
        }

        @keyframes swing {
            0% { transform: rotate(0deg); }
            25% { transform: rotate(5deg); }
            75% { transform: rotate(-5deg); }
            100% { transform: rotate(0deg); }
        }

        /* الشريط العلوي */
        .navbar {
            background: rgba(255, 255, 255, 0.15) !important;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.2) !important;
        }

        .navbar .navbar-brand,
        .navbar .nav-link {
            color: white !important;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }

        .navbar .nav-link:hover {
            color: var(--ramadan-gold) !important;
        }

        .navbar .dropdown-menu {
            background: rgba(30, 42, 71, 0.95);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            text-align: right;
        }

        .navbar .dropdown-item {
            color: white;
        }

        .navbar .dropdown-item:hover {
            background: rgba(247, 183, 49, 0.2);
            color: var(--ramadan-gold);
        }

        /* تخصيص Bootstrap للوضع الليلي */
        [data-bs-theme="dark"] .navbar {
            background: rgba(30, 30, 47, 0.8) !important;
        }

        [data-bs-theme="dark"] .card {
            background-color: rgba(30, 30, 47, 0.9);
            border-color: #2d2d44;
        }

        [data-bs-theme="dark"] .table {
            --bs-table-color: #f8f9fa;
            --bs-table-bg: transparent;
            --bs-table-border-color: #2d2d44;
            --bs-table-striped-bg: rgba(255,255,255,0.05);
        }

        /* تحسينات عامة */
        .btn {
            border-radius: 50px;
            padding: 0.6rem 1.8rem;
            font-weight: 600;
            transition: all 0.3s;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .card {
            border-radius: 20px;
            border: none;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            transition: all 0.3s;
            backdrop-filter: blur(10px);
            background-color: rgba(255, 255, 255, 0.85);
        }

        [data-bs-theme="dark"] .card {
            background-color: rgba(30, 30, 47, 0.85);
        }

        .card:hover {
            box-shadow: 0 15px 40px rgba(0,0,0,0.3);
        }

        .timer-container {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-radius: 50px;
            padding: 0.5rem 2rem;
            color: white;
            font-size: 2.2rem;
            font-weight: bold;
            display: inline-block;
            box-shadow: 0 10px 20px rgba(102,126,234,0.3);
        }

        /* تحسين العرض على الهواتف */
        @media (max-width: 768px) {
            .timer-container {
                font-size: 1.5rem;
                padding: 0.3rem 1rem;
            }
            h1 { font-size: 2rem; }
            .lantern {
                width: 40px;
                height: 60px;
            }
            .admin-sidebar {
                min-height: auto !important;
                border-left: none !important;
                border-bottom: 1px solid rgba(255, 255, 255, 0.2);
            }
        }

        /* شريط التقدم */
        .progress {
            height: 12px;
            border-radius: 10px;
            background-color: rgba(255,255,255,0.3);
        }
        .progress-bar {
            background: linear-gradient(90deg, #f7b731, #ffd966);
        }

        /* الشريط الجانبي للأدمن */
        .admin-sidebar {
            min-height: calc(100vh - 76px);
            background: rgba(255, 255, 255, 0.15);
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-left: 1px solid rgba(255, 255, 255, 0.2);
            padding: 1.5rem 0;
            box-shadow: -5px 0 20px rgba(0, 0, 0, 0.1);
        }

        [data-bs-theme="dark"] .admin-sidebar {
            background: rgba(30, 30, 47, 0.6);
            border-left-color: #2d2d44;
        }

        .admin-sidebar .nav-link {
            color: white;
            padding: 0.8rem 1.5rem;
            margin: 0.2rem 0;
            border-radius: 0 30px 30px 0;
            font-weight: 500;
            transition: all 0.2s;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
        }

        .admin-sidebar .nav-link:hover,
        .admin-sidebar .nav-link.active {
            background: linear-gradient(90deg, rgba(247, 183, 49, 0.3), transparent);
            color: #f7b731;
        }

        /* أنيميشن للمحتوى */
        main, .container-fluid {
            animation: fadeIn 0.5s ease-in;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
    @stack('styles')
</head>
<body>
    <!-- خلفية متحركة -->
    <div class="stars"></div>
    <div class="twinkling"></div>

    <!-- فوانيس -->
    <div class="lantern"></div>
    <div class="lantern right"></div>

    <!-- شريط التنقل -->
    <nav class="navbar navbar-expand-lg shadow-sm py-3 sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="{{ route('home') }}">
                <i class="bi bi-moon-stars-fill text-warning me-2"></i>
                مسابقة رمضان
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    @auth
                        <li class="nav-item">
                            <a class="nav-link {{ request()->routeIs('home') ? 'active' : '' }}" href="{{ route('home') }}">الرئيسية</a>
                        </li>
                        @if(auth()->user()->isAdmin())
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('admin.*') ? 'active' : '' }}" href="{{ route('admin.dashboard') }}">لوحة التحكم</a>
                            </li>
                        @endif
                        @if(auth()->user()->isSupervisor())
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('supervisor.*') ? 'active' : '' }}" href="{{ route('supervisor.dashboard') }}">لوحة المشرف</a>
                            </li>
                        @endif
                        @if(auth()->user()->isEditor())
                            <li class="nav-item">
                                <a class="nav-link {{ request()->routeIs('editor.*') ? 'active' : '' }}" href="{{ route('editor.questions.index') }}">إدارة الأسئلة</a>
                            </li>
                        @endif
                    @endauth
                </ul>
                <ul class="navbar-nav">
                    @auth
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="bi bi-person-circle fs-5 me-1"></i>
                                {{ auth()->user()->name }}
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li>
                                    <a class="dropdown-item" href="{{ route('student.profile') }}">
                                        <i class="bi bi-person-badge me-2"></i>الملف الشخصي
                                    </a>
                                </li>
                                <li><hr class="dropdown-divider"></li>
                                <li>
                                    <form method="POST" action="{{ route('logout') }}">
                                        @csrf
                                        <button class="dropdown-item" type="submit">
                                            <i class="bi bi-box-arrow-right me-2"></i>تسجيل خروج
                                        </button>
                                    </form>
                                </li>
                            </ul>
                        </li>
                    @else
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('login') }}">تسجيل دخول</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="{{ route('register') }}">تسجيل جديد</a>
                        </li>
                    @endauth
                    <li class="nav-item">
                        <button class="btn btn-link nav-link" id="darkModeToggle" title="تبديل الوضع الليلي">
                            <i class="bi bi-sun-fill" id="darkModeIcon"></i>
                        </button>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- المحتوى الرئيسي -->
    @if(auth()->check() && auth()->user()->isAdmin() && !request()->routeIs('admin.dashboard') && !request()->routeIs('admin.*.create') && !request()->routeIs('admin.*.edit') && !request()->routeIs('admin.*.import') && !request()->routeIs('admin.*.suggest'))
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3 col-lg-2 p-0 admin-sidebar">
                    @include('admin.layouts.sidebar')
                </div>
                <div class="col-md-9 col-lg-10 p-4">
                    @yield('content')
                </div>
            </div>
        </div>
    @else
        <main class="py-4">
            <div class="container">
                @yield('content')
            </div>
        </main>
    @endif

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    
    <script>
        // Toastr Configuration
        toastr.options = {
            "closeButton": true,
            "progressBar": true,
            "positionClass": "toast-top-left",
            "rtl": true,
            "timeOut": "5000",
        };

        // Dark mode toggle logic
        (function() {
            const html = document.documentElement;
            const icon = document.getElementById('darkModeIcon');
            const storedTheme = localStorage.getItem('theme');
            const systemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

            const setTheme = (theme) => {
                html.setAttribute('data-bs-theme', theme);
                localStorage.setItem('theme', theme);
                if (icon) {
                    icon.className = theme === 'dark' ? 'bi bi-moon-stars-fill' : 'bi bi-sun-fill';
                }
            };

            const initialTheme = storedTheme || (systemDark ? 'dark' : 'light');
            setTheme(initialTheme);

            document.getElementById('darkModeToggle')?.addEventListener('click', () => {
                const current = html.getAttribute('data-bs-theme');
                setTheme(current === 'dark' ? 'light' : 'dark');
            });
        })();
    </script>

    <!-- Flash messages -->
    @foreach(['success', 'error', 'info', 'warning'] as $msg)
        @if(session($msg))
            <script>toastr.{{ $msg === 'error' ? 'error' : $msg }}("{{ session($msg) }}");</script>
        @endif
    @endforeach

    @stack('scripts')
</body>
</html>
