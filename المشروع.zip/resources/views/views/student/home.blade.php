@extends('layouts.app')

@section('title', 'الأيام')

@section('content')
<div class="container py-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-5">
        <div>
            <h4 class="mb-1 fw-bold text-white">
                <i class="bi bi-star-fill text-warning me-2"></i>مرحباً، {{ auth()->user()->name }}
            </h4>
            <p class="text-white-50">اختر يوم المسابقة وابدأ التحدي</p>
        </div>

        @if(auth()->user()->status !== 'approved')
            <span class="badge bg-warning text-dark p-2 px-3 fs-6 rounded-pill shadow-sm">
                <i class="bi bi-hourglass-split me-1"></i> في انتظار الموافقة
            </span>
        @endif
    </div>

    @if(session('err'))
        <div class="alert alert-danger alert-dismissible fade show glass-card" role="alert">
            <i class="bi bi-exclamation-triangle me-2"></i>{{ session('err') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <div class="row g-4">
        @forelse($days as $d)
            <div class="col-12 col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="{{ $loop->index * 100 }}">
                <div class="card h-100 border-0 day-card glass-card {{ $d['status'] === 'open' ? 'ramadan-open' : '' }}">
                    <div class="card-body p-4">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="mb-0 fw-bold">
                                <i class="bi bi-calendar-day me-2 text-warning"></i>اليوم {{ $d['day_number'] }}
                            </h5>
                            @if($d['status'] === 'open')
                                <span class="badge bg-success px-3 py-2 rounded-pill">مفتوح الآن</span>
                            @elseif($d['status'] === 'closed')
                                <span class="badge bg-secondary px-3 py-2 rounded-pill">مغلق</span>
                            @else
                                <span class="badge bg-warning text-dark px-3 py-2 rounded-pill">قادم</span>
                            @endif
                        </div>

                        @if($d['title'])
                            <p class="text-muted mb-3">{{ $d['title'] }}</p>
                        @endif

                        <div class="small text-white-50 mb-3">
                            <div><i class="bi bi-clock me-1"></i> يبدأ: {{ \Carbon\Carbon::parse($d['starts_at'])->format('Y-m-d h:i A') }}</div>
                            <div><i class="bi bi-clock-history me-1"></i> ينتهي: {{ \Carbon\Carbon::parse($d['ends_at'])->format('Y-m-d h:i A') }}</div>
                        </div>

                        <div class="mt-4">
                            @if($d['status'] === 'open')
                                @php
                                    $attempt = auth()->user()->attempts()->where('competition_id', $d['id'])->first();
                                @endphp

                                @if($attempt && $attempt->status !== 'in_progress')
                                    <a href="{{ route('attempt.result', $attempt) }}" class="btn btn-outline-light w-100 rounded-pill">
                                        <i class="bi bi-eye me-2"></i>عرض نتيجتك
                                    </a>
                                @else
                                    <form method="POST" action="{{ route('attempt.start', $d['id']) }}">
                                        @csrf
                                        <button class="btn btn-lux w-100">
                                            <i class="bi bi-play-fill me-2"></i>ابدأ الاختبار
                                        </button>
                                    </form>
                                @endif

                            @elseif($d['status'] === 'closed')
                                @if($d['results_published'])
                                    <a href="{{ route('student.leaderboard', ['competition_id' => $d['id']]) }}"
                                       class="btn btn-outline-warning w-100 rounded-pill">
                                        <i class="bi bi-trophy me-2"></i>عرض الفائزين
                                    </a>
                                @else
                                    <button class="btn btn-outline-light w-100 rounded-pill" disabled>
                                        <i class="bi bi-hourglass-split me-2"></i>النتائج قريباً
                                    </button>
                                @endif
                            @else
                                <button class="btn btn-outline-light w-100 rounded-pill" disabled>
                                    <i class="bi bi-lock me-2"></i>غير متاح الآن
                                </button>
                            @endif
                        </div>
                    </div>
                    <!-- فانوس صغير في الخلفية -->
                    <div class="lantern-icon">🪔</div>
                </div>
            </div>
        @empty
            <div class="col-12">
                <div class="alert alert-info text-center py-5 glass-card">
                    <i class="bi bi-inbox fs-1 d-block mb-3"></i>
                    <h5>لا توجد مسابقات منشورة حالياً</h5>
                    <p class="mb-0">ترقبوا الإعلان عن المسابقات القادمة</p>
                </div>
            </div>
        @endforelse
    </div>
</div>
@endsection

@push('styles')
<style>
    /* تخصيص البطاقات */
    .day-card {
        background: rgba(255, 255, 255, 0.15) !important;
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        border: 1px solid rgba(255, 255, 255, 0.2) !important;
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
    }

    .day-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
        border-color: rgba(247, 183, 49, 0.5) !important;
    }

    .day-card .card-body {
        position: relative;
        z-index: 2;
        color: white;
    }

    /* أيقونة الفانوس في الخلفية */
    .lantern-icon {
        position: absolute;
        bottom: 10px;
        left: 10px;
        font-size: 3rem;
        opacity: 0.2;
        transform: rotate(10deg);
        transition: opacity 0.3s;
        z-index: 1;
    }

    .day-card:hover .lantern-icon {
        opacity: 0.4;
    }

    /* شارة الحالة */
    .badge.bg-success {
        background: rgba(25, 135, 84, 0.8) !important;
        backdrop-filter: blur(4px);
        border: 1px solid rgba(255, 255, 255, 0.2);
    }
    .badge.bg-secondary {
        background: rgba(108, 117, 125, 0.8) !important;
        backdrop-filter: blur(4px);
    }
    .badge.bg-warning {
        background: rgba(255, 193, 7, 0.8) !important;
        color: #1e2a47 !important;
    }

    /* أزرار */
    .btn-warning {
        background: #f7b731;
        border: none;
        color: #1e2a47;
        font-weight: 700;
    }
    .btn-warning:hover {
        background: #ffd966;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(247, 183, 49, 0.4);
    }

    .btn-outline-light {
        border: 2px solid rgba(255, 255, 255, 0.5);
        color: white;
        background: transparent;
    }
    .btn-outline-light:hover {
        background: rgba(255, 255, 255, 0.2);
        border-color: white;
        color: white;
    }

    .btn-outline-warning {
        border: 2px solid #f7b731;
        color: #f7b731;
    }
    .btn-outline-warning:hover {
        background: #f7b731;
        color: #1e2a47;
    }

    /* البطاقة الزجاجية للرسالة */
    .glass-card {
        background: rgba(255, 255, 255, 0.15) !important;
        backdrop-filter: blur(12px);
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: white;
    }

    /* الوضع الليلي */
    [data-bs-theme="dark"] .day-card {
        background: rgba(30, 30, 47, 0.6) !important;
    }
    [data-bs-theme="dark"] .btn-warning {
        background: #ffd966;
        color: #1e1e2f;
    }
    [data-bs-theme="dark"] .btn-outline-warning {
        border-color: #ffd966;
        color: #ffd966;
    }
    [data-bs-theme="dark"] .btn-outline-warning:hover {
        background: #ffd966;
        color: #1e1e2f;
    }

    /* نصوص */
    .text-white-50 {
        color: rgba(255, 255, 255, 0.7) !important;
    }
</style>
@endpush