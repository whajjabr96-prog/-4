

<?php $__env->startSection('title', 'اقتراح الفائزين'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-4">
    <h2 class="fw-bold mb-4"><i class="bi bi-magic me-2"></i>اقتراح فائزي اليوم <?php echo e($competition->day_number); ?></h2>

    <?php if(empty($suggested)): ?>
        <div class="alert alert-warning">
            <i class="bi bi-exclamation-triangle me-2"></i>
            لا توجد نتائج كافية لاقتراح فائزين.
        </div>
        <a href="<?php echo e(route('admin.competitions.winners.index', $competition)); ?>" class="btn btn-secondary">عودة</a>
    <?php else: ?>
        <div class="card shadow-sm border-0">
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('admin.competitions.winners.store', $competition)); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr><th>المركز</th><th>المستخدم</th><th>الدرجة</th><th>ملاحظات</th></tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $suggested; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <input type="number" name="winners[<?php echo e($index); ?>][rank]"
                                                   value="<?php echo e($item['rank']); ?>" class="form-control form-control-sm" style="width:80px;" readonly>
                                        </td>
                                        <td>
                                            <select name="winners[<?php echo e($index); ?>][user_id]" class="form-select" required>
                                                <option value="<?php echo e($item['user_id']); ?>" selected>
                                                    <?php echo e(\App\Models\User::find($item['user_id'])->name); ?>

                                                </option>
                                            </select>
                                        </td>
                                        <td><?php echo e($item['score']); ?></td>
                                        <td><input type="text" name="winners[<?php echo e($index); ?>][note]" class="form-control form-control-sm" placeholder="اختياري"></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <button type="submit" class="btn btn-success">حفظ الفائزين</button>
                    <a href="<?php echo e(route('admin.competitions.winners.index', $competition)); ?>" class="btn btn-secondary">إلغاء</a>
                </form>
            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ramadan1-quiz\resources\views\admin\winners\suggest.blade.php ENDPATH**/ ?>