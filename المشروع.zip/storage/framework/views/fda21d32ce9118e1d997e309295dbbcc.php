<?php if(isset($rows) && count($rows) > 0): ?>
    <table class="table table-hover align-middle">
        <thead class="table-light">
            <tr>
                <th>#</th>
                <th>الاسم</th>
                <th>البريد</th>
                <th>الهاتف</th>
                <th>التخصص</th>
                <th>رقم القيد</th>
                <th>الدور</th>
                <th>الحالة</th>
                <th>تاريخ التسجيل</th>
                <th>الإجراءات</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->phone); ?></td>
                    <td><?php echo e($user->major ?? '—'); ?></td>
                    <td><?php echo e($user->student_no ?? '—'); ?></td>
                    <td>
                        <?php if($user->role == 'admin'): ?>
                            <span class="badge bg-danger">مدير</span>
                        <?php elseif($user->role == 'supervisor'): ?>
                            <span class="badge bg-warning text-dark">مشرف</span>
                        <?php elseif($user->role == 'editor'): ?>
                            <span class="badge bg-info">محرر</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">طالب</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($user->status == 'approved'): ?>
                            <span class="badge bg-success">مقبول</span>
                        <?php elseif($user->status == 'pending'): ?>
                            <span class="badge bg-warning text-dark">قيد المراجعة</span>
                        <?php else: ?>
                            <span class="badge bg-danger">مرفوض</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($user->created_at->format('Y-m-d')); ?></td>
                    <td>
                        <div class="btn-group" role="group">
                            <?php if($mode !== 'approved'): ?>
                                <form method="POST" action="<?php echo e(route('admin.users.approve', $user)); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-sm btn-outline-success" title="قبول" onclick="return confirm('قبول هذا المستخدم؟')">
                                        <i class="bi bi-check-lg"></i>
                                    </button>
                                </form>
                            <?php endif; ?>

                            <?php if($mode !== 'rejected'): ?>
                                <form method="POST" action="<?php echo e(route('admin.users.reject', $user)); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-sm btn-outline-danger" title="رفض" onclick="return confirm('رفض هذا المستخدم؟')">
                                        <i class="bi bi-x-lg"></i>
                                    </button>
                                </form>
                            <?php endif; ?>

                            <?php if(auth()->user()->role == 'admin'): ?>
                                <a href="<?php echo e(route('admin.users.edit', $user)); ?>" class="btn btn-sm btn-outline-primary" title="تعديل">
                                    <i class="bi bi-pencil"></i>
                                </a>
                            <?php endif; ?>

                            <a href="<?php echo e(route('admin.users.show', $user)); ?>" class="btn btn-sm btn-outline-info" title="عرض">
                                <i class="bi bi-eye"></i>
                            </a>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php else: ?>
    <div class="text-center text-muted py-4">
        <i class="bi bi-inbox fs-1 d-block mb-3"></i>
        <p>لا يوجد مستخدمين في هذا القسم.</p>
    </div>
<?php endif; ?><?php /**PATH C:\laragon\www\ramadan1-quiz\resources\views\admin\users\partials\table.blade.php ENDPATH**/ ?>